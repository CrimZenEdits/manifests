-- Fetch from public repos for AppID: 1501750
-- Game: Lords of the Fallen
addappid(1501750)
addappid(1501751, 1, "C86A5D17AC060ED8C27BC9840A5EB75890D5D8CF1908993635A947D13A30076B")
addappid(2387921, 0, "")

-- Set Manifest GIDs
setManifestid(1501751, "1887491025439424369", 0)
setManifestid(2387921, "6553904194185226573", 0)